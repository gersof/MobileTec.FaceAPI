﻿// Decompiled with JetBrains decompiler
// Type: MobileTec.FaceAPI.PoC.FaceClient.Contract.FaceLandmarks
// Assembly: MobileTec.FaceAPI.PoC.FaceClient, Version=1.2.1.1, Culture=neutral, PublicKeyToken=31bf3856ad364e35
// MVID: E1C430B0-5B4F-40C0-B7F6-ACC82F4C9CFC
// Assembly location: C:\Users\jangu\Downloads\FaceAPI_MVC\packages\MobileTec.FaceAPI.PoC.FaceClient.1.2.1.2\lib\portable-net45+wp80+win8+wpa81+aspnetcore50\MobileTec.FaceAPI.PoC.FaceClient.dll

namespace MobileTec.FaceAPI.PoC.FaceClient.Contract
{
  public class FaceLandmarks
  {
    public FeatureCoordinate PupilLeft { get; set; }

    public FeatureCoordinate PupilRight { get; set; }

    public FeatureCoordinate NoseTip { get; set; }

    public FeatureCoordinate MouthLeft { get; set; }

    public FeatureCoordinate MouthRight { get; set; }

    public FeatureCoordinate EyebrowLeftOuter { get; set; }

    public FeatureCoordinate EyebrowLeftInner { get; set; }

    public FeatureCoordinate EyeLeftOuter { get; set; }

    public FeatureCoordinate EyeLeftTop { get; set; }

    public FeatureCoordinate EyeLeftBottom { get; set; }

    public FeatureCoordinate EyeLeftInner { get; set; }

    public FeatureCoordinate EyebrowRightInner { get; set; }

    public FeatureCoordinate EyebrowRightOuter { get; set; }

    public FeatureCoordinate EyeRightInner { get; set; }

    public FeatureCoordinate EyeRightTop { get; set; }

    public FeatureCoordinate EyeRightBottom { get; set; }

    public FeatureCoordinate EyeRightOuter { get; set; }

    public FeatureCoordinate NoseRootLeft { get; set; }

    public FeatureCoordinate NoseRootRight { get; set; }

    public FeatureCoordinate NoseLeftAlarTop { get; set; }

    public FeatureCoordinate NoseRightAlarTop { get; set; }

    public FeatureCoordinate NoseLeftAlarOutTip { get; set; }

    public FeatureCoordinate NoseRightAlarOutTip { get; set; }

    public FeatureCoordinate UpperLipTop { get; set; }

    public FeatureCoordinate UpperLipBottom { get; set; }

    public FeatureCoordinate UnderLipTop { get; set; }

    public FeatureCoordinate UnderLipBottom { get; set; }
  }
}
